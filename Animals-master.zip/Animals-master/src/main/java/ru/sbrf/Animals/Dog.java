package ru.sbrf.Animals;

public class Dog extends Animals {
    public static String dog1() {
        String ClimbTrees = "no";
        return ClimbTrees;
    }
    public static String dog2() {
        String Swim = "yes";
        return Swim;
    }
    public static String dog3(){
        String Sound = "yes";
        return (Sound);
    }
    public static String dog4 () {
        String Eat = "yes";
        return (Eat);
    }
    public static String dog5() {
        String Move = "yes";
        return (Move);
    }
}

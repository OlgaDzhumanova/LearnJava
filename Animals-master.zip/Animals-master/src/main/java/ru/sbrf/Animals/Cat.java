package ru.sbrf.Animals;

public class Cat extends Animals{

    public static String cat1() {
        String ClimbTrees = "yes";
        return ClimbTrees;
    }
    public static String cat2() {
        String Swim = "no";
        return Swim;
    }
    public static String cat3(){
        String Sound = "yes";
        return (Sound);
    }
    public static String cat4 () {
        String Eat = "yes";
        return (Eat);
    }
    public static String cat5() {
        String Move = "yes";
        return (Move);
    }
}
package ru.sbrf.Animals;

public class Mammals extends Animals {
    public static String mamm1() {
        String ClimbTrees = "no";
        return ClimbTrees;
    }
    public static String mamm2() {
        String Swim = "no";
        return Swim;
    }
    public static String mamm3(){
        String Sound = "yes";
        return (Sound);
    }
    public static String mamm4 () {
        String Eat = "yes";
        return (Eat);
    }
    public static String mamm5() {
        String Move = "no";
        return (Move);
    }
}

package ru.sbrf.Animals;

public class Animals {

public void ClimbTrees(String ClimbTrees) {
     if(ClimbTrees == "yes"){
         System.out.println("ClimbTrees on");
     }else {
         System.out.println("ClimbTrees off");
     }
}
public void Swim (String Swim){
    if(Swim == "yes"){
        System.out.println("Swim on");
    }else {
        System.out.println("Swim off");
    }
}
    public void Sound(String Sound) {
        if (Sound == "yes") {
        System.out.println("Sound on");
        } else {
        System.out.println("Sound off");
    }
}
    public void Eat(String Eat) {
    if (Eat == "yes") {
        System.out.println("Eat on");
    } else {
        System.out.println("Eat off");
    }
}

    public void Move (String Move) {
    if(Move == "yes"){
            System.out.println("Move on");
        }else {
            System.out.println("Move off");
        }
    }
}


